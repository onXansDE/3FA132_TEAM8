package de.fentacore.interfaces;

import java.util.UUID;

public interface IId {

   UUID getId();

   void setId(UUID id);

}
